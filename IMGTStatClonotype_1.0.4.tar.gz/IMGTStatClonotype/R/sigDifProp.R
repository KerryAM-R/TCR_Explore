#'  Significance of the difference in proportions with 95\% confidence interval (CI) for IMGT clonotype (AA) diversity between two sets from IMGT/HighV-QUEST output
#'
#'  This function tests the significance of the difference in proportions with 95\% confidence interval (CI) for IMGT clonotype (AA) diversity.
#'
#' @param Data the matrix issued from the function \code{\link{clonNumDiv}} containing the number of IMGT clonotypes (AA)
#' @param data1 the first set from IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @param  data2 the second set from IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @return A matrix of 21 columns:
#'  \item{Gene_Name}{
#'  The list of IMGT gene names found in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{Gene_Type}{
#'  The type of genes (V, D or J)
#'  }
#'  \item{Nb_IMGT_clonotype_AA.set1}{
#'  The nb of IMGT clonotypes (AA) in the first IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'   \item{Proportion.set1}{
#'  The proportion of IMGT clonotypes (AA) in the first IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Normalized_proportion.set1}{
#'  The normalized proportion for 10000 IMGT clonotypes (AA) in the first IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Nb_IMGT_clonotype_AA.set2}{
#'  The nb of IMGT clonotypes (AA) in the second IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Proportion.set2}{
#'  The proportion of IMGT clonotypes (AA) in the second IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Normalized_proportion.set2}{
#'  The normalized proportion for 10000 IMGT clonotypes (AA) in the second IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Difference_proportion}{
#'  The difference in proportions of IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{z}{
#'  The \emph{z}-score values to determine the significance of the difference between two proportions
#'  }
#'  \item{Lower_bound_IC_diff_prop}{
#'  The lower bound of the 95\% confidence interval (CI) for the difference in proportions of IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{Upper_bound_IC_diff_prop}{
#'  The upper bound of the 95\% confidence interval (CI) for the difference in proportions of IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{rawp}{
#'  The \emph{p}-values obtained from z-scores to evaluate the significance of difference in proportions of IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{Bonferroni}{
#'  The adjusted \emph{p}-values issued from the Bonferroni multiple testing procedure
#'  }
#'  \item{Holm}{
#'  The adjusted \emph{p}-values issued from the Holm multiple testing procedure
#'  }
#'  \item{Hochberg}{
#'  The adjusted \emph{p}-values issued from the Hochberg multiple testing procedure
#'  }
#'  \item{SidakSS}{
#'  The adjusted \emph{p}-values issued from the Sidak single-step (SS) multiple testing procedure
#'  }
#'  \item{SidakSD}{
#'  The adjusted \emph{p}-values issued from the Sidak single-down (SD) multiple testing procedure
#'  }
#'  \item{BH}{
#'  The adjusted \emph{p}-values issued from the Benjamini & Hochberg (BH) multiple testing procedure
#'  }
#'  \item{BY}{
#'  The adjusted \emph{p}-values issued from the Benjamini & Yekutieli (BY) multiple testing procedure
#'  }
#'  \item{Test_interpretation}{
#'  The test interpretation: before adjustment of \emph{p}-values (rawp) non-significant and after adjustment by the multiple testing procedure: significant differences in proportions validated by the seven procedures (All_p), by two or more procedures (Min_2p) and only by BH (Only_BH)
#'  }
#' @name sigrepDiv
#' @source Gentleman R.C., Carey V.J., Bates D.M., Bolstad B., Dettling M., Dudoit S., et al. (2004) Bioconductor: Open software development for computational biology and bioinformatics R. Genome Biology, Vol. 5, R80, \url{https://www.bioconductor.org/}
#' @references Pollard K.S., Dudoit S., van der Laan M.J. (2005). Multiple testing procedures: R multtest package and applications to genomics. \emph{In}: Bioinformatics and Computational Biology Solutions Using R and Bioconductor. Gentleman R., Carey V.J., Huber W., Irizarry R.A., Dudoit S. (Eds) Springer (Statistics for Biology and Health Series), pp. 251-272.
#'
#' @examples
#' \dontrun{
#'  div<-sigrepDiv(Ndiv,MID1,MID2)
#' }
#' @import multtest
#' @export
sigrepDiv<-function(Data,data1,data2){
  ifelse(length(Data)==0, {
    dataRes <-data.frame(
      Gene_Name=character(), Gene_Type=numeric(), Nb_IMGT_clonotype_AA.set1=integer(), Proportion.set1=integer(), Normalized_proportion.set1=numeric(),
      Nb_IMGT_clonotype_AA.set2=integer(), Proportion.set2=integer(), Normalized_proportion.set2=numeric(), Difference_proportion=numeric(), z=numeric(),
      Lower_bound_IC_diff_prop=numeric(), Upper_bound_IC_diff_prop=numeric(), rawp =numeric(), Bonferroni=numeric(), Holm=numeric(), Hochberg=numeric(),
      SidakSS=numeric(),  SidakSD=numeric(), BH=numeric(), BY=numeric(), Test_interpretation=numeric() )},{
        #Creation of the data base "report" containing test results
        report <- data.frame(Gene_Name=Data$Gene_Name)
        #report$Gene_Type <- paste(sapply(strsplit(as.character(report[,1]), " "), function(x) substr(x[[2]],4,4)), "gene")
        report$Gene_Type <- paste(substr(sapply(strsplit(as.character(report[,1]), " "),'[', 2),4,4), "gene")
        #Number of IMGT clonotype (AA) in the second set
        report$Nb_IMGT_clonotype_AA.set1 <- Data$Proportion.set1
        #Proportion in the first set
        report$Proportion.set1 <- Data$Proportion.set1/length(clonRem(data1)$expid)
        #Normalized proportion for the set 1
        report$Normalized_proportion.set1    <-  report$Proportion.set1*10000
        #Number of IMGT clonotype (AA) in the second set
        report$Nb_IMGT_clonotype_AA.set2<-Data$Proportion.set2
        #Proportion in the second set
        report$Proportion.set2   <- Data$Proportion.set2/length(clonRem(data2)$expid)
        #Normalized proportion for the set 2
        report$Normalized_proportion.set2 <-  report$Proportion.set2*10000
        #Difference in proportions
        report$Difference_proportion  <- report$Proportion.set1-report$Proportion.set2
        #Estimation of combined p
        report$p.estime  <- ((length(clonRem(data1)$expid)*report$Proportion.set1)+(length(clonRem(data2)$expid)*report$Proportion.set2))/(length(clonRem(data1)$expid)+length(clonRem(data2)$expid))
        #Test creteria
        report$z <- ifelse(report$p.estime==0.0000000000, 0, (report$Proportion.set1-report$Proportion.set2)/sqrt((report$p.estime*(1-report$p.estime))*((1/length(clonRem(data1)$expid))+(1/length(clonRem(data2)$expid)))))
        #Test interpretation with H0: Proportion.set1=Proportion.set2= p.estime
        report$Test_interpretation1 <- rep("No Significant difference", length(report$z))
        report$Test_interpretation1 <- ifelse(report$z==0 | is.na(report$z), "Null proportion difference ", ifelse((abs(report$z)> 1.96)==TRUE, "Significant difference", report$Test_interpretation1))
        report$z <- ifelse(report$z==0 ,"Not defined",report$z)
        report[,'z'] <- round(report[,'z'], 2)
        #Erreur standard
        report$sigma <- sqrt(((report$Proportion.set1*(1-report$Proportion.set1))/(length(clonRem(data1)$expid)))+((report$Proportion.set2*(1-report$Proportion.set2))/(length(clonRem(data2)$expid))))
        #Lower bound of the 95\% for the difference in proporttion
        report$Lower_bound_IC_diff_prop <- report$Difference_proportion - 1.96*report$sigma
        #Upper bound of the 95\% for the difference in proportion
        report$Upper_bound_IC_diff_prop <- report$Difference_proportion+ 1.96*report$sigma
        #p-values generation
        report$p <- 2*stats::pnorm(-abs(report$z))
        #######################
        report$p <- 2*stats::pnorm(-abs(report$z))
        report$nbfisher1 <- length(clonRem(data1)$expid)- report$Nb_IMGT_clonotype_AA.set1
        report$nbfisher2 <- length(clonRem(data2)$expid)- report$Nb_IMGT_clonotype_AA.set2
        row_fisher <- function(row, alt = 'two.sided', cnf = 0.95) {
          fisher <- stats::fisher.test(matrix(row, nrow = 2), alternative = alt, conf.level = cnf)
          return(c(row,
                   p_value_fisher = fisher$p.value))
        }

        testdf <- data.frame(report$Nb_IMGT_clonotype_AA.set1, report$Nb_IMGT_clonotype_AA.set2,report$nbfisher1, report$nbfisher2 )
        colnames(testdf) <- c('Nb_IMGT_clonotype_AA.set1', 'Nb_IMGT_clonotype_AA.set1','nbfisher1','nbfisher2')
        p <-as.data.frame(t(apply(testdf, 1, row_fisher)))
        report$fisher <- p$p_value_fisher
        report$p[report$Nb_IMGT_clonotype_AA.set1<5 | report$Nb_IMGT_clonotype_AA.set2<5] <- report$fisher[report$Nb_IMGT_clonotype_AA.set1<5 | report$Nb_IMGT_clonotype_AA.set2<5]
        report <- report[,!(names(report)) %in% c("nbfisher1", "nbfisher2","fisher")]
        ##########################
        #p-values adjustment with multiple testing procedures
        procs <- c("Bonferroni", "Holm", "Hochberg", "SidakSS", "SidakSD", "BH", "BY")
        rawp <- report$p
        res <- mt.rawp2adjp(rawp, procs)
        allp <- res$adjp[order(res$index), ]
        report<-data.frame(cbind(report[,1:15],allp[1:length(report$Gene_Name), ]))
        report$SidakSS[report$SidakSS==0 |is.na(report$SidakSS)] <- report$rawp[report$SidakSS==0|is.na(report$rawp)]
        report$SidakSS[report$SidakSD==0 |is.na(report$SidakSD)] <- report$rawp[report$SidakSD==0|is.na(report$rawp)]
        report$Test_interpretation <- ifelse((report$rawp> 0.05)& (is.na(report$rawp)==FALSE), "Non-significant (rawp)  ",
                                             ifelse((report$rawp< 0.05)  &(report$Bonferroni> 0.05)&(report$Holm> 0.05)&(report$Hochberg> 0.05)&(report$SidakSS> 0.05)&(report$SidakSD> 0.05)&(report$BH> 0.05)&(report$BY> 0.05)& (is.na(report$rawp)==FALSE), "Significant (rawp)  ",
                                                    ifelse((is.na(report$rawp)==TRUE), "Null difference in proportions  ",
                                                           ifelse((report$rawp< 0.05) &(report$Bonferroni< 0.05)&(report$Holm< 0.05)&(report$Hochberg< 0.05)&(report$SidakSS< 0.05)&(report$SidakSD< 0.05)&(report$BH<0.05)&(report$BY< 0.05) & (is.na(report$rawp)==FALSE), "Significant (All_p)  " ,
                                                                  ifelse((report$rawp< 0.05) & (report$BH< 0.05)  &(report$Bonferroni> 0.05)&(report$Holm> 0.05)&(report$Hochberg> 0.05)&(report$SidakSS> 0.05)&(report$SidakSD> 0.05)&(report$BY> 0.05)& (is.na(report$rawp)==FALSE), "Significant (Only_BH)  ", "Significant (Min_2p)  ")
                                                           )
                                                    )
                                             )
        )
        dataRes<-report[c(1:9,11,14:24)]})
  return(dataRes)
}

#' Significance of the difference in proportions with 95\% confidence interval (CI) for IMGT clonotype (AA) expression between two sets from IMGT/HighV-QUEST output
#'
#' This function tests the significance of the difference in proportions with 95\% confidence interval (CI) for IMGT clonotype (AA) expression.
#'
#' @param Data the matrix issued from the function \code{\link{clonNumExp}} containing the number of IMGT clonotypes (AA)
#' @param data1 the first set from the  IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @param data2 the second set from the IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @return A matrix of 21 columns:
#'  \item{Gene_Name}{
#'  The list of IMGT gene names found in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{Gene_Type}{
#'  The type of genes (V, D or J)
#'  }
#'  \item{Nb_IMGT_clonotype_AA.set1}{
#'  The nb of sequences assigned to IMGT clonotypes (AA) in the first IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'   \item{Proportion.set1}{
#'  The proportion of sequences assigned to IMGT clonotypes (AA) in the first IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Normalized_proportion.set1}{
#'  The normalized proportion for 10000 sequences assigned to IMGT clonotypes (AA) in the first IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Nb_IMGT_clonotype_AA.set2}{
#'  The nb of sequences assigned to IMGT clonotypes (AA) in the second IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Proportion.set2}{
#'  The proportion of sequences assigned to IMGT clonotypes (AA) in the second IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Normalized_proportion.set2}{
#'  The normalized proportion for 10000 sequences assigned to IMGT clonotypes (AA) in the second IMGT/HighV-QUEST output (set) with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{Difference_proportion}{
#'  The difference in proportions of sequences assigned to IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output with the corresponding gene indicated in the first column "Gene_Name"
#'  }
#'  \item{z}{
#'  The \emph{z}-score values to determine the significance of the difference between two proportions
#'  }
#'  \item{Lower_bound_IC_diff_prop}{
#'  The lower bound of the 95\% confidence interval (CI) for the difference in proportions of sequences assigned to IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{Upper_bound_IC_diff_prop}{
#'  The upper bound of the 95\% confidence interval (CI) for the difference in proportions of sequences assigned to IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{rawp}{
#'  The \emph{p}-values obtained from \emph{z}-scores to evaluate the significance of difference in proportions of sequences assigned to IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output
#'  }
#'  \item{Bonferroni}{
#'  The adjusted \emph{p}-values issued from the Bonferroni multiple testing procedure
#'  }
#'  \item{Holm}{
#'  The adjusted \emph{p}-values issued from the Holm multiple testing procedure
#'  }
#'  \item{Hochberg}{
#'  The adjusted \emph{p}-values issued from the Hochberg multiple testing procedure
#'  }
#'  \item{SidakSS}{
#'  The adjusted \emph{p}-values issued from the Sidak single-step (SS) multiple testing procedure
#'  }
#'  \item{SidakSD}{
#'  The adjusted \emph{p}-values issued from the Sidak single-down (SD) multiple testing procedure
#'  }
#'  \item{BH}{
#'  The adjusted \emph{p}-values issued from the Benjamini & Hochberg (BH) multiple testing procedure
#'  }
#'  \item{BY}{
#'  The adjusted \emph{p}-values issued from the Benjamini & Yekutieli (BY) multiple testing procedure
#'  }
#'  \item{Test_interpretation}{
#'  The test interpretation: before adjustment of \emph{p}-values (rawp) non-significant and after adjustment by the multiple testing procedure: significant differences in proportions validated by the seven procedures (All_p), by two or more procedures (Min_2p) and only by BH (Only_BH)
#'  }
#' @name sigrepExp
#' @source Gentleman R.C., Carey V.J., Bates D.M., Bolstad B., Dettling M., Dudoit S., et al. (2004) Bioconductor: Open software development for computational biology and bioinformatics R. Genome Biology, Vol. 5, R80, \url{https://www.bioconductor.org/}
#' @references Pollard K.S., Dudoit S., van der Laan M.J. (2005). Multiple testing procedures: R multtest package and applications to genomics. \emph{In}: Bioinformatics and Computational Biology Solutions Using R and Bioconductor. Gentleman R., Carey V.J., Huber W., Irizarry R.A., Dudoit S. (Eds) Springer (Statistics for Biology and Health Series), pp. 251-272.
#'
#' @examples
#' \dontrun{
#' exp<-sigrepExp(Nexp,MID1,MID2)
#' }
#'
#' @export
  sigrepExp<-function(Data,data1,data2){
    ifelse(length(Data)==0, { dataRes <-data.frame(
      Gene_Name=character(), Gene_Type=numeric(), Nb_IMGT_clonotype_AA.set1=integer(), Proportion.set1=integer(), Normalized_proportion.set1=numeric(),
      Nb_IMGT_clonotype_AA.set2=integer(), Proportion.set2=integer(), Normalized_proportion.set2=numeric(), Difference_proportion=numeric(), z=numeric(),
      Lower_bound_IC_diff_prop=numeric(), Upper_bound_IC_diff_prop=numeric(), rawp =numeric(), Bonferroni=numeric(), Holm=numeric(), Hochberg=numeric(),
      SidakSS=numeric(),  SidakSD=numeric(), BH=numeric(), BY=numeric(), Test_interpretation=numeric() )},{
  #Creation of the data base "report" containing test results
  report <- data.frame(Gene_Name=Data$Gene_Name)
  #report$Gene_Type <- paste(sapply(strsplit(as.character(report[,1]), " "), function(x) substr(x[[2]],4,4)), "gene")
  report$Gene_Type <- paste(substr(sapply(strsplit(as.character(report[,1]), " "),'[', 2),4,4), "gene")
  #Number of sequences assigned to IMGT clonotype (AA) in the first set
  report$Nb_IMGT_clonotype_AA.set1 <- Data$Proportion.set1
  #proportion for the set 1
  report$Proportion.set1 <- Data$Proportion.set1/sum(clonRem(data1)$total)
  #Normalized proportion for the set 1
  report$Normalized_proportion.set1 <- report$Proportion.set1*10000
  #Number of sequences assigned to IMGT clonotype (AA) in the second set
  report$Nb_IMGT_clonotype_AA.set2 <- Data$Proportion.set2
  #Proportion in the second set
  report$Proportion.set2 <- Data$Proportion.set2/sum(clonRem(data2)$total)
  #Normalized proportion for the set 1
  report$Normalized_proportion.set2 <- report$Proportion.set2*10000
  #Difference in proportions
  report$Difference_proportion <- report$Proportion.set1-report$Proportion.set2
  #Estimation of combined p
  report$p.estime <- ((length(clonRem(data1)$expid)*report$Proportion.set1)+(length(clonRem(data2)$expid)*report$Proportion.set2))/(length(clonRem(data1)$expid)+length(clonRem(data2)$expid))
  #Test creteria
  report$z <- ifelse(report$p.estime==0.0000000000, 0, (report$Proportion.set1-report$Proportion.set2)/sqrt((report$p.estime*(1-report$p.estime))*((1/length(clonRem(data1)$expid))+(1/length(clonRem(data2)$expid)))))
  #Test interpretation with H0: Proportion.set1=Proportion.set2= p.estime
  report$Test_interpretation1 <- rep("No Significant difference", length(report$z))
  report$Test_interpretation1 <- ifelse(report$z==0 | is.na(report$z), "Null proportion difference ", ifelse((abs(report$z)> 1.96)==TRUE, "Significant difference", report$Test_interpretation1))
  report$z <- ifelse(report$z==0 ,"Not defined",report$z)
  report[,'z'] <- round(report[,'z'], 2)
  #Erreur standard
  report$sigma <- sqrt(((report$Proportion.set1*(1-report$Proportion.set1))/(sum(clonRem(data1)$total)))+((report$Proportion.set2*(1-report$Proportion.set2))/(sum(clonRem(data2)$total))))
  #Lower bound of the 95\% for the difference in proporttion
  report$Lower_bound_IC_diff_prop <- report$Difference_proportion - 1.96*report$sigma
  #Upper bound of the 95\% for the difference in proportion
  report$Upper_bound_IC_diff_prop <- report$Difference_proportion+ 1.96*report$sigma
  #p-values generation
  report$p <- 2*stats::pnorm(-abs(report$z))
  #######################
  report$p <- 2*stats::pnorm(-abs(report$z))
  report$nbfisher1 <- sum(clonRem(data1)$total)- report$Nb_IMGT_clonotype_AA.set1
  report$nbfisher2 <- sum(clonRem(data2)$total)- report$Nb_IMGT_clonotype_AA.set2
  row_fisher <- function(row, alt = 'two.sided', cnf = 0.95) {
    fisher <- stats::fisher.test(matrix(row, nrow = 2), alternative = alt, conf.level = cnf)
    return(c(row,
             p_value_fisher = fisher$p.value))
  }
  testdf <- data.frame(report$Nb_IMGT_clonotype_AA.set1, report$Nb_IMGT_clonotype_AA.set2,report$nbfisher1, report$nbfisher2 )
  colnames(testdf) <- c('Nb_IMGT_clonotype_AA.set1', 'Nb_IMGT_clonotype_AA.set1','nbfisher1','nbfisher2')
  p <-as.data.frame(t(apply(testdf, 1, row_fisher)))
  report$fisher <- p$p_value_fisher
  report$p[report$Nb_IMGT_clonotype_AA.set1<5 | report$Nb_IMGT_clonotype_AA.set2<5] <- report$fisher[report$Nb_IMGT_clonotype_AA.set1<5 | report$Nb_IMGT_clonotype_AA.set2<5]
  report <- report[,!(names(report)) %in% c("nbfisher1", "nbfisher2","fisher")]
  ##########################
  #p-values adjustment with multiple testing procedures
  procs <- c("Bonferroni", "Holm", "Hochberg", "SidakSS", "SidakSD", "BH", "BY")
  rawp <- report$p
  res <- mt.rawp2adjp(rawp, procs)
  allp <- res$adjp[order(res$index), ]
  report <- data.frame(cbind(report[,1:15],allp[1:length(report$Gene_Name), ]))
  report$SidakSS[report$SidakSS==0 |is.na(report$SidakSS)] <- report$rawp[report$SidakSS==0|is.na(report$rawp)]
  report$SidakSS[report$SidakSD==0 |is.na(report$SidakSD)] <- report$rawp[report$SidakSD==0|is.na(report$rawp)]
  report$Test_interpretation <- ifelse((report$rawp> 0.05)& (is.na(report$rawp)==FALSE), "Non-significant (rawp)  ",
                                       ifelse((report$rawp< 0.05)  &(report$Bonferroni> 0.05)&(report$Holm> 0.05)&(report$Hochberg> 0.05)&(report$SidakSS> 0.05)&(report$SidakSD> 0.05)&(report$BH> 0.05)&(report$BY> 0.05)& (is.na(report$rawp)==FALSE), "Significant (rawp)  ",
                                              ifelse((is.na(report$rawp)==TRUE), "Null difference in proportions  ",
                                                     ifelse((report$rawp< 0.05) &(report$Bonferroni< 0.05)&(report$Holm< 0.05)&(report$Hochberg< 0.05)&(report$SidakSS< 0.05)&(report$SidakSD< 0.05)&(report$BH<0.05)&(report$BY< 0.05) & (is.na(report$rawp)==FALSE), "Significant (All_p)  " ,
                                                            ifelse((report$rawp< 0.05) & (report$BH< 0.05)  &(report$Bonferroni> 0.05)&(report$Holm> 0.05)&(report$Hochberg> 0.05)&(report$SidakSS> 0.05)&(report$SidakSD> 0.05)&(report$BY> 0.05)& (is.na(report$rawp)==FALSE), "Significant (Only_BH)  ", "Significant (Min_2p)  ")
                                                           )
                                                     )
                                              )
                                       )
  dataRes<-report[c(1:9,11,14:24)]})
    return(dataRes)
  }



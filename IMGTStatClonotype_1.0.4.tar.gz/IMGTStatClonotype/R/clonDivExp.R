#' Gene presence/absence in the IMGT clonotypes (AA) for clonotype diversity
#'
#' This function allows the creation of a new boolean matrix indicating the presence (coded by 1) or the absence (coded by 0) of genes in the IMGT clonotypes (AA) for clonotype diversity.
#'
#' @param datag IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @param data issued from the function \code{\link{meltgene}}
#' @return Boolean matrix with IMGT clonotypes (AA) in rows and gene names in columns.
#' @name preabsDiv
#' @examples
#' \dontrun{
#' b1<-preabsDiv(MID1,set1)
#' b2<-preabsDiv(MID2,set2)
#' }
#' @export
preabsDiv<-function(datag,data){
  n1<-length(datag$expid)
  n2<-length(levels(factor(clonRem(datag)$vgene)))+length(levels(factor(clonRem(datag)$jgene)))+length(levels(factor(clonRem(datag)$dgene)))
  a <- matrix (rep(0, n1*n2), n1, n2, dimnames = list((datag$expid), c(levels(factor(clonRem(datag)$vgene)),levels(factor(clonRem(datag)$jgene)),levels(factor(clonRem(datag)$dgene)))))
  f1<-function(x){which(names(a[,1])==x)}
  f2<-function(x){which(names(a[1,])==x)}
  l <- data.frame(mapply(f1,data$expid),mapply(f2,data$Gene_Name))
  for(i in 1:length(l[,1])){
                            a[l[i,1],l[i,2]]<-1}
  ifelse(( "" %in% colnames(a)) ==TRUE, return(a[ , -which(colnames(a) %in% "")]), return(a))
}

#' Gene presence/absence in the IMGT clonotypes (AA) for clonotype expression
#'
#' This function allows the creation of a new matrix indicating the presence or the absence of genes in the sequences assigned to IMGT clonotypes (AA) for clonotype expression.
#'
#' @param datag IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @param data issued from the function \code{\link{meltgene}}
#' @return Matrix with sequences assigned to IMGT clonotypes (AA) in rows and gene names in columns.
#' @name preabsExp
#' @examples
#' \dontrun{
#' e1<-preabsExp(MID1,set1)
#' e2<-preabsExp(MID2,set2)
#' }
#' @export
 preabsExp<-function(datag,data){
  n1<-length(clonRem(datag)$expid)
  n2<-length(levels(factor(clonRem(datag)$vgene)))+length(levels(factor(clonRem(datag)$jgene)))+length(levels(factor(clonRem(datag)$dgene)))
  a <- matrix (rep(0, n1*n2), n1, n2, dimnames = list((datag$expid), c(levels(factor(clonRem(datag)$vgene)),levels(factor(clonRem(datag)$jgene)),levels(factor(clonRem(datag)$dgene)))))
  f1<-function(x){which(names(a[,1])==x)}
  f2<-function(x){which(names(a[1,])==x)}
  l <- data.frame(mapply(f1,data$expid),mapply(f2,data$Gene_Name))
  a[as.matrix(l)] <- data$total
  ifelse(( "" %in% colnames(a)) ==TRUE, return(a[ , -which(colnames(a) %in% "")]), return(a))
 }

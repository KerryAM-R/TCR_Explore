#' IMGT/StatClonotype launch
#'
#' This function launches the application IMGT/StatClonotype pairwise comparisons through a user-friendly interface in the web browser.
#'
#' @return An interaction tool to visualize pairwise comparison between sets from IMGT/HighV-QUEST output. If no errors occurred this function returns (\code{NULL}) else it returns error(s) message(s) shown in the R console.
#' @keywords IMGT/StatClonotype
#' @examples
#' \dontrun{
#' launch()
#' }
#' @importFrom shiny dataTableOutput
#' @importFrom shiny renderDataTable
#' @importFrom plotly renderPlotly
#' @importFrom plotly plotlyOutput
#' @importFrom shiny runApp
#' @importFrom shinyjs toggle
#' @importFrom DT datatable
#' @importFrom colourpicker colourInput
#' @importFrom d3heatmap d3heatmap
#' @export
  launch <- function(){
  appDir <- system.file("shiny-app", "myapp", package = "IMGTStatClonotype")
  if (appDir == "") {
                     stop("Could not find example directory. Try re-installing `IMGTStatClonotype`.", call. = FALSE)
                     }
         runApp(appDir, display.mode = "normal")

}

#' List of IMGT V and J genes
#'
#' This function allows the creation of a new matrix grouping the columns vgene, dgene and jgene in one column with their identifier (ID).
#'
#' This function must be applied for the two sets from the IMGT/HighV-QUEST output to be compared. It is based on the function melt of the package reshape2.
#'
#' @param data  a set from the IMGT/HighV-QUEST output
#' @param ... further arguments passed to or from other methods
#' @param variable.name name of variable used to store measured variable names, by default "Gene_Type"
#' @param value.name name of variable used to store values, by default "Gene_Name"
#' @importFrom reshape2 melt
#' @importFrom data.table setDT
#' @return New matrix with 4 columns: "expid" (Experimental ID), "total" (Total nb of `1 copy` and `More than one`), "Gene_Type" (V D or J genes), "Gene_Name" (Gene names).
#' @name meltgene
#' @references Wickham H. (2007) Reshaping Data with the reshape Package. Journal of Statistical Software, 21(12), 1-20. \url{http://www.jstatsoft.org/v21/i12/}
#' @examples
#' \dontrun{
#' set1<-meltgene(MID1)
#' set2<-meltgene(MID2)
#' }
#' @export
  meltgene <-function(data,..., variable.name="Gene_Type", value.name = "Gene_Name"){
    ifelse( identical( levels(as.factor(data$dgene)), character(0))==TRUE,
  MID<-melt(setDT(data[c(2,6,8,12)]),id.vars=c("expid","total"),variable.name=variable.name,value.name =value.name),
  MID<-melt(setDT(data[c(2,6,8,10,12)]),id.vars=c("expid","total"),variable.name=variable.name,value.name =value.name)
    )
  return(MID)
  }

#' Numbers of IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output for clonotype diversity
#'
#' This function allows the creation of a matrix containing the number of IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output with an IMGT gene of a given IMGT V, D or J group (IMGT clonotypes (AA) diversity).
#'
#' @param data1 the first set from the IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @param data2 the second set from the IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @return Matrix with IMGT gene names in rows and numbers of IMGT clonotypes (AA) in columns.
#' @name clonNumDiv
#' @examples
#' \dontrun{
#' Ndiv<-clonNumDiv(MID1,MID2)
#' }
#' @export
clonNumDiv<-function(data1,data2){
  clonNumDivVJ<-function(data1,data2){
    MaxGeneList<-function(data1,data2){
      utils::data("GeneList", envir = environment())
      GeneList <- get("GeneList", envir  = environment())
      li1<-c(levels(factor(clonRem(data1)$vgene,exclude=c("","NA"))),levels(factor(clonRem(data1)$jgene,exclude=c("","NA"))))
      li2<-c(levels(factor(clonRem(data2)$vgene,exclude=c("","NA"))),levels(factor(clonRem(data2)$jgene,exclude=c("","NA"))))
      li<-levels(as.factor(c(li1,li2)))
      lia1<-c(levels(factor(clonRem(data1)$vallele,exclude=c("","NA"))),levels(factor(clonRem(data1)$jallele,exclude=c("","NA"))))
      lia2<-c(levels(factor(clonRem(data2)$vallele,exclude=c("","NA"))),levels(factor(clonRem(data2)$jallele,exclude=c("","NA"))))
      lia<-levels(as.factor(c(lia1,lia2)))
      fonctionality<-sapply(strsplit(lia, " "), "[", 3)
      genenamefromallele<-sapply(strsplit(lia, "\\*"), "[", 1)
      genewithf<-paste(genenamefromallele[match(li, genenamefromallele)],fonctionality[match(li, genenamefromallele)])
      geneswithoutf<-paste(sapply(strsplit(genewithf, " "), "[", 1), sapply(strsplit(genewithf, " "), "[", 2))
      i<-match(li, GeneList[["GeneList"]],nomatch=0)
      if (identical(li[i == 0], character(0))==FALSE){
        GeneListModified<-GeneList
        q<-data.frame(li[i == 0])
        q$Species<-sapply(strsplit(as.character(q[,1]), " "), "[", 1)
        q$GeneListF<-genewithf[match(as.character(q[,1]),geneswithoutf)]
        q$Locus <- substr(sapply(strsplit(as.character(q[,1]), " "),'[', 2),1,3)
        colnames(q)<-c("GeneList","Species","GeneListF","Locus")
        GeneListModified<-rbind(GeneListModified, q)
        r<-sort(match(li, GeneList$GeneList,nomatch=0))
        r<-sort(match(li, GeneListModified$GeneList))
        g<-GeneListModified[r[1:length(r)],1]
        h<-GeneListModified[r[1:length(r)],3]} else if (identical(li[i == 0], character(0))==TRUE){
          utils::data("GeneList", envir = environment())
          GeneList <- get("GeneList", envir  = environment())
          li1<-c(levels(factor(clonRem(data1)$vgene,exclude=c("","NA"))),levels(factor(clonRem(data1)$jgene,exclude=c("","NA"))))
          li2<-c(levels(factor(clonRem(data2)$vgene,exclude=c("","NA"))),levels(factor(clonRem(data2)$jgene,exclude=c("","NA"))))
          li<-levels(as.factor(c(li1,li2)))
          i<-sort(match(li, GeneList$GeneList))
          g<-GeneList[i[1: length(i)],1]
          h<-GeneList[i[1: length(i)],3]}
      list(g=g,h=h)
    }

    BasePropEmpty<-function(data1,data2){
      n1<- length(MaxGeneList(data1,data2)$h)
      b <- matrix (rep(0, n1*2), n1, 2,dimnames =list(MaxGeneList(data1,data2)$h,c("Gene_Name_without_Functionality","Gene_Name")))
      d<-data.frame(b, row.names = NULL)
      d[,1]<-MaxGeneList(data1,data2)$g
      d[,2]<-MaxGeneList(data1,data2)$h
      return(d)
    }
    b0<-BasePropEmpty(data1,data2)
    t1vj=rbind(as.data.frame(table(data1$vgene)),as.data.frame(table(data1$jgene)))
    colnames(t1vj) <- c('Gene_Name','Proportion.set1')
    t2vj=rbind(as.data.frame(table(data2$vgene)),as.data.frame(table(data2$jgene)))
    colnames(t2vj) <- c('Gene_Name','Proportion.set2')
    df <- merge(t1vj, t2vj, all = TRUE)
    df[is.na(df)] <- 0
    b0f <- df[match(b0$Gene_Name_without_Functionality, df$Gene_Name),]
    b0 <- cbind(b0f[,1], b0[,2],b0f[,2:3])
    colnames(b0) <- c('Gene_Name_without_Functionality','Gene_Name','Proportion.set1','Proportion.set2')
    naf<-which(sapply(b0[,2], function(x)all(is.na(x)))==TRUE)
    if (length(naf)!=0){
      b0$Gene_Name_without_Functionality<-as.character(b0$Gene_Name_without_Functionality)
      b0$Gene_Name<-as.character(b0$Gene_Name)
      for (i in ((length(b0[,1])-length(naf))+1):(length(b0[,1]))) {
        b0[i,2]<-b0[i,1]}
      b0$Gene_Name_without_Functionality<-as.factor(b0$Gene_Name_without_Functionality)
      b0$Gene_Name<-as.factor(b0$Gene_Name)
      return(b0[,2:4])} else if (length(naf)==0){return(b0[,2:4])}
  }
  ifelse(identical( levels(as.factor((data1$dgene))), "")==FALSE | identical( levels(as.factor((data2$dgene))), "")==FALSE,{
    clonNumDivDgene<-function(data1,data2){
      data1 <- data1[which(data1$dgene != ""), ]
      data2 <- data2[which(data2$dgene != ""), ]
      MaxGeneList<-function(data1,data2){
        utils::data("GeneList", envir = environment())
        GeneList <- get("GeneList", envir  = environment())
        li1<-c(levels(factor(clonRem(data1)$dgene,exclude=c("","NA"))))
        li2<-c(levels(factor(clonRem(data2)$dgene,exclude=c("","NA"))))
        li<-levels(as.factor(c(li1,li2)))
        lia1<-c(levels(factor(clonRem(data1)$dallele,exclude=c("","NA"))))
        lia2<-c(levels(factor(clonRem(data2)$dallele,exclude=c("","NA"))))
        lia<-levels(as.factor(c(lia1,lia2)))
        fonctionality<-sapply(strsplit(lia, " "), "[", 3)
        genenamefromallele<-sapply(strsplit(lia, "\\*"), "[", 1)
        genewithf<-paste(genenamefromallele[match(li, genenamefromallele)],fonctionality[match(li, genenamefromallele)])
        geneswithoutf<-paste(sapply(strsplit(genewithf, " "), "[", 1), sapply(strsplit(genewithf, " "), "[", 2))
         i<-match(li, GeneList[["GeneList"]],nomatch=0)
        if (identical(li[i == 0], character(0))==FALSE){
          GeneListModified<-GeneList
          q<-data.frame(li[i == 0])
          q$Species<-sapply(strsplit(as.character(q[,1]), " "), "[", 1)
          q$GeneListF<-genewithf[match(as.character(q[,1]),geneswithoutf)]
          q$Locus <- substr(sapply(strsplit(as.character(q[,1]), " "),'[', 2),1,3)
          colnames(q)<-c("GeneList","Species","GeneListF","Locus")
          GeneListModified<-rbind(GeneListModified, q)
          r<-sort(match(li, GeneList$GeneList,nomatch=0))
          r<-sort(match(li, GeneListModified$GeneList))
          g<-GeneListModified[r[1:length(r)],1]
          h<-GeneListModified[r[1:length(r)],3]} else if (identical(li[i == 0], character(0))==TRUE){
            utils::data("GeneList", envir = environment())
            GeneList <- get("GeneList", envir  = environment())
            li1<-c(levels(factor(clonRem(data1)$dgene,exclude=c("","NA"))))
            li2<-c(levels(factor(clonRem(data2)$dgene,exclude=c("","NA"))))
            li<-c(li1,li2)
            li<-levels(as.factor(li))
            i<-sort(match(li, GeneList$GeneList))
            g<-GeneList[i[1: length(i)],1]
            h<-GeneList[i[1: length(i)],3]}
        list(g=g,h=h)
      }

      BasePropEmpty<-function(data1,data2){
        n1<- length(MaxGeneList(data1,data2)$h)
        b <- matrix (rep(0, n1*2), n1, 2,dimnames =list(MaxGeneList(data1,data2)$h,c("Gene_Name_without_Functionality","Gene_Name")))
        d<-data.frame(b, row.names = NULL)
        d[,1]<-MaxGeneList(data1,data2)$g
        d[,2]<-MaxGeneList(data1,data2)$h
        return(d)
      }
      b0d<-BasePropEmpty(data1,data2)
      t1d = as.data.frame(table(data1$dgene))
      t2d = as.data.frame(table(data2$dgene))
      ifelse(nrow(t1d)!=0,colnames(t1d) <- c('Gene_Name','Proportion.set1'), colnames(t1d) <- c('Gene_Name')  )

      t2d = as.data.frame(table(data2$dgene))
      ifelse(nrow(t2d)!=0,colnames(t2d) <- c('Gene_Name','Proportion.set2'), colnames(t2d) <- c('Gene_Name')  )
      df <- merge(t1d, t2d, all = TRUE)
      df[is.na(df)] <- 0
      df <- df[which(df$Gene_Name != ""), ]
      ifelse(ncol(df)==3, df <- df, {
        ifelse(colnames(df[2])=="Proportion.set1",{ df$Proportion.set2 <- 0},{df$Proportion.set1 <- 0
        df <- df[,c("Gene_Name","Proportion.set1","Proportion.set2")]
        df}) })
      b0f <- df[match(b0d$Gene_Name_without_Functionality, df$Gene_Name),]
      b0d <- cbind(b0f[,1], b0d[,2],b0f[,2:3])
      colnames(b0d) <- c('Gene_Name_without_Functionality','Gene_Name','Proportion.set1','Proportion.set2')
      naf<-which(sapply(b0d[,2], function(x)all(is.na(x)))==TRUE)
      if (length(naf)!=0){
        b0d$Gene_Name_without_Functionality<-as.character(b0d$Gene_Name_without_Functionality)
        b0d$Gene_Name<-as.character(b0d$Gene_Name)
        for (i in ((length(b0d[,1])-length(naf))+1):(length(b0d[,1]))) {
          b0d[i,2]<-b0d[i,1]}
        b0d$Gene_Name_without_Functionality<-as.factor(b0d$Gene_Name_without_Functionality)
        b0d$Gene_Name<-as.factor(b0d$Gene_Name)
        return(b0d[,2:4])} else if (length(naf)==0){return(b0d[,2:4])}
    }
    return(rbind(clonNumDivVJ(data1,data2),clonNumDivDgene(data1,data2))) },
    return(clonNumDivVJ(data1,data2)))
}

#' Numbers of IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output for clonotype expression
#'
#' This function allows the creation of a matrix containing the number of sequences assigned to IMGT clonotypes (AA) in the two compared sets from the IMGT/HighV-QUEST output with an IMGT gene of a given IMGT V, D or J group (IMGT clonotypes (AA) expression).
#'
#' @param data1 the first set from the IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @param data2 the second set from the IMGT/HighV-QUEST output without CDR3-IMGT outlier lengths issued from the function \code{\link{clonRem}}
#' @return Matrix with IMGT gene names in rows and numbers of IMGT clonotypes (AA) in columns.
#' @name clonNumExp
#' @examples
#' \dontrun{
#'  Nexp<-clonNumExp(MID1,MID2)
#' }
#' @export

clonNumExp<-function(data1,data2){
  clonNumExpVJ<-function(data1,data2){
    MaxGeneList<-function(data1,data2){
      li1<-c(levels(factor(clonRem(data1)$vgene,exclude=c("","NA"))),levels(factor(clonRem(data1)$jgene,exclude=c("","NA"))))
      li2<-c(levels(factor(clonRem(data2)$vgene,exclude=c("","NA"))),levels(factor(clonRem(data2)$jgene,exclude=c("","NA"))))
      li<-levels(as.factor(c(li1,li2)))
      lia1<-c(levels(factor(clonRem(data1)$vallele,exclude=c("","NA"))),levels(factor(clonRem(data1)$jallele,exclude=c("","NA"))))
      lia2<-c(levels(factor(clonRem(data2)$vallele,exclude=c("","NA"))),levels(factor(clonRem(data2)$jallele,exclude=c("","NA"))))
      lia<-levels(as.factor(c(lia1,lia2)))
      fonctionality<-sapply(strsplit(lia, " "), "[", 3)
      genenamefromallele<-sapply(strsplit(lia, "\\*"), "[", 1)
      genewithf<-paste(genenamefromallele[match(li, genenamefromallele)],fonctionality[match(li, genenamefromallele)])
      geneswithoutf<-sapply(strsplit(genewithf, " "), function(x) paste(x[[1]],x[[2]]))
      i<-match(li, GeneList$GeneList,nomatch=0)
      if (identical(li[i == 0], character(0))==FALSE){
        GeneListModified<-GeneList
        q<-data.frame(li[i == 0])
        q$Species<-sapply(strsplit(as.character(q[,1]), " "), "[", 1)
        q$GeneListF<-genewithf[match(as.character(q[,1]),geneswithoutf)]
        q$Locus <- substr(sapply(strsplit(as.character(q[,1]), " "),'[', 2),1,3)
        colnames(q)<-c("GeneList","Species","GeneListF","Locus")
        GeneListModified<-rbind(GeneListModified, q)
        r<-sort(match(li, GeneList$GeneList,nomatch=0))
        r<-sort(match(li, GeneListModified$GeneList))
        g<-GeneListModified[r[1:length(r)],1]
        h<-GeneListModified[r[1:length(r)],3]} else if (identical(li[i == 0], character(0))==TRUE){
          utils::data("GeneList", envir = environment())
          GeneList <- get("GeneList", envir  = environment())
          li1<-c(levels(factor(clonRem(data1)$vgene)),levels(factor(clonRem(data1)$jgene)))
          li2<-c(levels(factor(clonRem(data2)$vgene)),levels(factor(clonRem(data2)$jgene)))
          li<-levels(as.factor(c(li1,li2)))
          i<-sort(match(li, GeneList$GeneList))
          g<-GeneList[i[1: length(i)],1]
          h<-GeneList[i[1: length(i)],3]}
      list(g=g,h=h)
    }

    BasePropEmpty<-function(data1,data2){
      n1<- length(MaxGeneList(data1,data2)$h)
      b <- matrix (rep(0, n1*2), n1, 2,dimnames =list(MaxGeneList(data1,data2)$h,c("Gene_Name_without_Functionality","Gene_Name")))
      d<-data.frame(b, row.names = NULL)
      d[,1]<-MaxGeneList(data1,data2)$g
      d[,2]<-MaxGeneList(data1,data2)$h
      return(d)
    }
    b0<-BasePropEmpty(data1,data2)
    w1v=as.data.frame(stats::aggregate(total~vgene, data=data1,sum))
    colnames(w1v) <- c('Gene_Name', 'Proportion.set1')
    w1j=as.data.frame(stats::aggregate(total~jgene, data=data1,sum))
    colnames(w1j) <- c('Gene_Name', 'Proportion.set1')
    t1vj=rbind(w1v,w1j)
    w2v=as.data.frame(stats::aggregate(total~vgene, data=data2,sum))
    colnames(w2v) <- c('Gene_Name', 'Proportion.set2')
    w2j=as.data.frame(stats::aggregate(total~jgene, data=data2,sum))
    colnames(w2j) <- c('Gene_Name', 'Proportion.set2')
    t2vj=rbind(w2v,w2j)
    df <- merge(t1vj, t2vj, all = TRUE)
    df[is.na(df)] <- 0
    b0f <- df[match(b0$Gene_Name_without_Functionality, df$Gene_Name),]
    b0 <- cbind(b0f[,1], b0[,2],b0f[,2:3])
    colnames(b0) <- c('Gene_Name_without_Functionality','Gene_Name','Proportion.set1','Proportion.set2')
    naf<-which(sapply(b0[,2], function(x)all(is.na(x)))==TRUE)
    if (length(naf)!=0){
      b0$Gene_Name_without_Functionality<-as.character(b0$Gene_Name_without_Functionality)
      b0$Gene_Name<-as.character(b0$Gene_Name)
      for (i in ((length(b0[,1])-length(naf))+1):(length(b0[,1]))) {
        b0[i,2]<-b0[i,1] }
      b0$Gene_Name_without_Functionality<-as.factor(b0$Gene_Name_without_Functionality)
      b0$Gene_Name<-as.factor(b0$Gene_Name)
      return(b0[,2:4])} else if (length(naf)==0){return(b0[,2:4])}
  }
  ifelse(identical( levels(as.factor((data1$dgene))), "")==FALSE | identical( levels(as.factor((data2$dgene))), "")==FALSE,{
    clonNumExpDgene<-function(data1,data2){
      data1 <- data1[which(data1$dgene != ""), ]
      data2 <- data2[which(data2$dgene != ""), ]
      MaxGeneList<-function(data1,data2){
        li1<-c(levels(factor(clonRem(data1)$dgene,exclude=c("","NA"))))
        li2<-c(levels(factor(clonRem(data2)$dgene,exclude=c("","NA"))))
        li<-levels(as.factor(c(li1,li2)))
        lia1<-c(levels(factor(clonRem(data1)$dallele,exclude=c("","NA"))))
        lia2<-c(levels(factor(clonRem(data2)$dallele,exclude=c("","NA"))))
        lia<-levels(as.factor(c(lia1,lia2)))
        fonctionality<-sapply(strsplit(lia, " "), "[", 3)
        genenamefromallele<-sapply(strsplit(lia, "\\*"), "[", 1)
        genewithf<-paste(genenamefromallele[match(li, genenamefromallele)],fonctionality[match(li, genenamefromallele)])
        geneswithoutf<-sapply(strsplit(genewithf, " "), function(x) paste(x[[1]],x[[2]]))
        i<-match(li, GeneList$GeneList,nomatch=0)

        if (identical(li[i == 0], character(0))==FALSE){
          li[i == 0]
          GeneListModified<-GeneList
          q<-data.frame(li[i == 0])
          gg<-match(as.character(q[,1]),geneswithoutf)
          q$Species<-sapply(strsplit(as.character(q[,1]), " "), "[", 1)
          q$GeneListF<-genewithf[gg]
          q$Locus <- substr(sapply(strsplit(as.character(q[,1]), " "),'[', 2),1,3)
          colnames(q)<-c("GeneList","Species","GeneListF","Locus")
          GeneListModified<-rbind(GeneListModified, q)
          r<-sort(match(li, GeneList$GeneList,nomatch=0))
          r<-sort(match(li, GeneListModified$GeneList))
          g<-GeneListModified[r[1:length(r)],1]
          h<-GeneListModified[r[1:length(r)],3]} else if (identical(li[i == 0], character(0))==TRUE){
            utils::data("GeneList", envir = environment())
            GeneList <- get("GeneList", envir  = environment())
            li1<-c(levels(factor(clonRem(data1)$dgene)))
            li2<-c(levels(factor(clonRem(data2)$dgene)))
            li<-levels(as.factor(c(li1,li2)))
            i<-sort(match(li, GeneList$GeneList))
            g<-GeneList[i[1: length(i)],1]
            h<-GeneList[i[1: length(i)],3]}
        list(g=g,h=h)
      }

      BasePropEmpty<-function(data1,data2){
        n1<- length(MaxGeneList(data1,data2)$h)
        b <- matrix (rep(0, n1*2), n1, 2,dimnames =list(MaxGeneList(data1,data2)$h,c("Gene_Name_without_Functionality","Gene_Name")))
        d<-data.frame(b, row.names = NULL)
        d[,1]<-MaxGeneList(data1,data2)$g
        d[,2]<-MaxGeneList(data1,data2)$h
        return(d)
      }
      b0<-BasePropEmpty(data1,data2)
      w1d=as.data.frame(stats::aggregate(total~dgene, data=data1,sum))
      colnames(w1d) <- c('Gene_Name', 'Proportion.set1')
      w2d=as.data.frame(stats::aggregate(total~dgene, data=data2,sum))
      colnames(w2d) <- c('Gene_Name', 'Proportion.set2')
      df <- merge(w1d, w2d, all = TRUE)
      df[is.na(df)] <- 0
      b0f <- df[match(b0$Gene_Name_without_Functionality, df$Gene_Name),]
      b0 <- cbind(b0f[,1], b0[,2],b0f[,2:3])
      colnames(b0) <- c('Gene_Name_without_Functionality','Gene_Name','Proportion.set1','Proportion.set2')
      naf<-which(sapply(b0[,2], function(x)all(is.na(x)))==TRUE)
      if (length(naf)!=0){
        b0$Gene_Name_without_Functionality<-as.character(b0$Gene_Name_without_Functionality)
        b0$Gene_Name<-as.character(b0$Gene_Name)
        for (i in ((length(b0[,1])-length(naf))+1):(length(b0[,1]))) {
          b0[i,2]<-b0[i,1]}
        b0$Gene_Name_without_Functionality<-as.factor(b0$Gene_Name_without_Functionality)
        b0$Gene_Name<-as.factor(b0$Gene_Name)
        return(b0[,2:4])} else if (length(naf)==0){return(b0[,2:4])}
    }
    return(rbind(clonNumExpVJ(data1,data2),clonNumExpDgene(data1,data2)))},
    return(clonNumExpVJ(data1,data2)))
}

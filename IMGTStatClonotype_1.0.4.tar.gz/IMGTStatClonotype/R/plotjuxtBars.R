#' Normalized bar graph of the proportions
#'
#' This function draws the normalized bar graph of the proportions of IMGT clonotypes (AA) (or sequences assigned to IMGT clonotypes (AA)).
#'
#' @param data the data isssued from the function \code{\link{sigrepDiv}} or \code{\link{sigrepExp}}
#' @param ... optional parameters
#' @import ggplot2
#' @import gridExtra
#' @importFrom reshape2 melt
#' @return Normalized juxtaposed bar graphs of the proportions of IMGT clonotypes (AA) (or sequences assigned to IMGT clonotypes (AA)) in two compared sets from IMGT/HighV-QUEST output.
#' @name normjuxBars
#' @examples
#' \dontrun{
#' normjuxBars(div)$BarGphV
#' normjuxBars(div)$BarGphD
#' normjuxBars(div)$BarGphJ
#' normjuxBars(exp)$BarGphV
#' normjuxBars(exp)$BarGphD
#' normjuxBars(exp)$BarGphJ
#' }
#' @keywords IMGTHVQplots
#' @export
  normjuxBars<-function(data,...){
    dataV <- data[which(data$Gene_Type=="V gene"),]
    data1V=reshape2::melt(dataV[c(1,2,5,8)], id.vars = c("Gene_Name", "Gene_Type"))
    pBV<-with(data1V, ggplot(data=data1V) +theme_grey()+
      geom_bar(aes(x=Gene_Name,y =value,fill =factor(variable, levels = rev(levels(variable)))), position="dodge",stat = "identity", colour="black",show.legend=FALSE)+
      geom_bar(aes(x=Gene_Name,y =value,fill =factor(variable, levels = rev(levels(variable)))), position="dodge",stat = "identity")+
      coord_flip() +xlab("V genes")+ylab("Normalized proportions")+
      scale_x_discrete(limits= rev(factor(factor(dataV$Gene_Name),levels=levels(as.factor(dataV$Gene_Name)))))+
        theme(
          panel.grid.major = element_line(size = 0.5),
          panel.border = element_rect(linetype = "solid", colour = "#808080", fill=NA),
          legend.position="bottom",
          plot.title=element_text( face="bold", size = unit(14, "pt")),
          strip.text.x = element_text(size=unit(10, "pt"), colour="black"),
          axis.title.x = element_text(size = unit(10, "pt"),face="bold", colour="black",vjust=-0.5),
          axis.text.x=element_text(size = unit(10, "pt"), colour="black"),
          strip.text.y = element_text(size=unit(10, "pt"), face="bold", colour="black"),
          axis.title.y = element_text(size = unit(10, "pt"),face="bold", colour="black", vjust=1.5),
          axis.text.y=element_text( size = unit(10, "pt"),hjust=0, colour="black"),
          strip.background = element_rect( colour="#808080", fill="#DBDBDB", size=1, linetype="solid"),
          legend.background = element_rect(colour = "black"),
          legend.title = element_text(size=unit(8, "pt"), face="bold"),
          legend.text = element_text(size = unit(8, "pt"), face = "bold",vjust=1.5),
          legend.key.size = unit(0.35, "cm"))+
        guides(fill=guide_legend(title = "Compared sets: ",nrow=2,keywidth =1.5, keyheight = 1,reverse = TRUE)))

    dataJ <- data[which(data$Gene_Type=="J gene"),]
    data1J=reshape2::melt(dataJ[c(1,2,5,8)], id.vars = c("Gene_Name", "Gene_Type"))
    pBJ<-with(data1J, ggplot(data=data1J) +theme_grey()+
                geom_bar(aes(x=Gene_Name,y =value,fill =factor(variable, levels = rev(levels(variable)))), position="dodge",stat = "identity", colour="black",show.legend=FALSE)+
                geom_bar(aes(x=Gene_Name,y =value,fill =factor(variable, levels = rev(levels(variable)))), position="dodge",stat = "identity")+
                coord_flip() +xlab("J genes")+ylab("Normalized proportions")+
                scale_x_discrete(limits= rev(factor(factor(dataJ$Gene_Name),levels=levels(as.factor(dataJ$Gene_Name)))))+
                theme(
                  panel.grid.major = element_line(size = 0.5),
                  panel.border = element_rect(linetype = "solid", colour = "#808080", fill=NA),
                  legend.position="bottom",
                  plot.title=element_text( face="bold", size = unit(14, "pt")),
                  strip.text.x = element_text(size=unit(10, "pt"), colour="black"),
                  axis.title.x = element_text(size = unit(10, "pt"),face="bold", colour="black",vjust=-0.5),
                  axis.text.x=element_text(size = unit(10, "pt"), colour="black"),
                  strip.text.y = element_text(size=unit(10, "pt"), face="bold", colour="black"),
                  axis.title.y = element_text(size = unit(10, "pt"),face="bold", colour="black", vjust=1.5),
                  axis.text.y=element_text( size = unit(10, "pt"),hjust=0, colour="black"),
                  strip.background = element_rect( colour="#808080", fill="#DBDBDB", size=1, linetype="solid"),
                  legend.background = element_rect(colour = "black"),
                  legend.title = element_text(size=unit(8, "pt"), face="bold"),
                  legend.text = element_text(size = unit(8, "pt"), face = "bold",vjust=1.5),
                  legend.key.size = unit(0.35, "cm"))+
                guides(fill=guide_legend(title = "Compared sets: ",nrow=2,keywidth =1.5, keyheight = 1,reverse = TRUE)))

    dataD <- data[which(data$Gene_Type=="D gene"),]
    data1D=reshape2::melt(dataD[c(1,2,5,8)], id.vars = c("Gene_Name", "Gene_Type"))
    pBD<-with(data1D, ggplot(data=data1D) +theme_grey()+
                geom_bar(aes(x=Gene_Name,y =value,fill =factor(variable, levels = rev(levels(variable)))), position="dodge",stat = "identity", colour="black",show.legend=FALSE)+
                geom_bar(aes(x=Gene_Name,y =value,fill =factor(variable, levels = rev(levels(variable)))), position="dodge",stat = "identity")+
                coord_flip() +xlab("D genes")+ylab("Normalized proportions")+
                scale_x_discrete(limits= rev(factor(factor(dataD$Gene_Name),levels=levels(as.factor(dataD$Gene_Name)))))+
                theme(
                  panel.grid.major = element_line(size = 0.5),
                  panel.border = element_rect(linetype = "solid", colour = "#808080", fill=NA),
                  legend.position="bottom",
                  plot.title=element_text( face="bold", size = unit(14, "pt")),
                  strip.text.x = element_text(size=unit(10, "pt"), colour="black"),
                  axis.title.x = element_text(size = unit(10, "pt"),face="bold", colour="black",vjust=-0.5),
                  axis.text.x=element_text(size = unit(10, "pt"), colour="black"),
                  strip.text.y = element_text(size=unit(10, "pt"), face="bold", colour="black"),
                  axis.title.y = element_text(size = unit(10, "pt"),face="bold", colour="black", vjust=1.5),
                  axis.text.y=element_text( size = unit(10, "pt"),hjust=0, colour="black"),
                  strip.background = element_rect( colour="#808080", fill="#DBDBDB", size=1, linetype="solid"),
                  legend.background = element_rect(colour = "black"),
                  legend.title = element_text(size=unit(8, "pt"), face="bold"),
                  legend.text = element_text(size = unit(8, "pt"), face = "bold",vjust=1.5),
                  legend.key.size = unit(0.35, "cm"))+
                guides(fill=guide_legend(title = "Compared sets: ",nrow=2,keywidth =1.5, keyheight = 1,reverse = TRUE)))
    list(BarGphV=pBV,BarGphD=pBD,BarGphJ=pBJ)
 # Remove the # symbol in the lines below if you want to have a combined graph for V,D and J genes
 #   g_legend<-function(a.gplot){
 #    tmp <- ggplot_gtable(ggplot_build(a.gplot))
 #     leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
 #     legend <- tmp$grobs[[leg]]
 #     return(legend)}
 #   commonlegend<-g_legend(pBV)
 #   grid.arrange(arrangeGrob(pBV+theme(legend.position = "none"),
 #                           pBD+theme(legend.position = "none"),
#                            pBJ+theme(legend.position = "none"),
 #                           nrow=2,heights=c(1, 0.5)),
 #               commonlegend, nrow=3,heights=c(15, 1,0.25))
}

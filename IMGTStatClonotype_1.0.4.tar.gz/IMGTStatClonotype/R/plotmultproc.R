#' Multiples testing procedures displays
#'
#' This function draws graphs from multiple testing results. It displays the number of rejected hypotheses plotted against the
#' Type I error rate for each of the procedures and the ordered adjusted \emph{p}-values plotted for each of the
#' procedures obtained by using the functions mt.plot of the package multtest (plottype: "rvsa" and "pvst" respectively).
#'
#' @param data the data isssued from the function \code{\link{sigrepDiv}} or \code{\link{sigrepExp}}
#' @param ... optional parameters
#' @import gridExtra
#' @import multtest
#' @importFrom graphics text
#' @return Graphs from multiple testing results.
#' @name multprocPlot
#' @source Gentleman R.C., Carey V.J., Bates D.M., Bolstad B., Dettling M., Dudoit S., et al. (2004) Bioconductor: Open software development for computational biology and bioinformatics R. Genome Biology, Vol. 5, R80, \url{https://www.bioconductor.org/}
#' @references Pollard K.S., Dudoit S., van der Laan M.J. (2005). Multiple testing procedures: R multtest package and applications to genomics. \emph{In}: Bioinformatics and Computational Biology Solutions Using R and Bioconductor. Gentleman R., Carey V.J., Huber W., Irizarry R.A., Dudoit S. (Eds) Springer (Statistics for Biology and Health Series), pp. 251-272.
#' @examples
#' \dontrun{
#' dev.new(width=6.7, height=3.14)
#' multprocPlot(div)
#' multprocPlot(exp)
#' }
#' @keywords IMGTHVQplots
#' @export
 multprocPlot<-function(data,...){
  res<-multtest::mt.rawp2adjp(data$rawp, proc=c("Bonferroni", "Holm", "Hochberg", "SidakSS", "SidakSD","BH", "BY"), alpha = 0.05, na.rm = FALSE)
  adjp <- res$adjp[order(res$index), ]
  cols <- c(1, "#B200FF", 3, 4, 5,6,10,"#FFBA00")
  ltypes <- c("dotted","solid","solid","solid","solid","solid","solid","solid")
  ltypess <- c(15,16,16,16,16,16,17,17)
  procs <- c("rawp","Bonferroni", "Holm", "Hochberg", "SidakSS", "SidakSD", "BH", "BY")
  graphics::layout(matrix(c(1,2,3,3), ncol=2, byrow=TRUE), heights=c(3.25, 0.25))
  graphics::par(mai=c(0.75,0.75,0.25,0.25),cex=0.6)
  multtest::mt.plot(adjp,plottype="rvsa", logscale=TRUE,cex.lab=1,lab=c(20,12,0.3),leg=FALSE,lty=ltypes, proc = procs,col=cols, lwd=3,cex=0.75)
  graphics::par(xpd=FALSE)
  graphics::abline(v=0.05,col="blue", lty=3, cex=0.5)
  multtest::mt.plot(adjp,data$z ,plottype="pvst",cex.lab=1,leg=FALSE, logscale=TRUE,pch=ltypess,col=cols,cex=0.85, lwd=2)
  graphics::par(xpd=FALSE)
  graphics::abline(h=1.3,col="blue", lty=3, cex=0.5)
  graphics::abline(v=c(-1.96,1.96),col="blue", lty=3, cex=0.5)
  graphics::par(mai=c(0,0,0,0),cex=0.4)
  graphics::plot.new()
  graphics::legend(x="top", horiz = TRUE,legend=procs,pch=ltypess,col=cols,box.lwd=0.5, lwd=2,text.width=rep(0.08,8))
}

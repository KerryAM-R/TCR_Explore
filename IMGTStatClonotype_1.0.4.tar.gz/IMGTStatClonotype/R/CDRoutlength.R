#'  CDR3-IMGT outlier length
#'
#' This function removes IMGT clonoypes (AA) with CDR3-IMGT outlier lengths depending on the studied species (for \emph{Homo sapiens} by default >=45 and <=4).
#'
#' @param set the set from the IMGT/HighV-QUEST output to be compared
#' @param min the lower level of CDR3-IMGT length
#' @param max the upper level of CDR3-IMGT length
#' @return This function returns sets from the IMGT/HighV-QUEST output without IMGT clonotypes (AA) having CDR3-IMGT outlier lengths. A matrix of 25 columns:
#'  \item{cdr3aa}{
#'  CDR3-IMGT sequence (AA)}
#'  \item{expid}{
#'  Experimental ID}
#'  \item{clonoIndex}{
#'  Representative sequence index }
#'  \item{onecopy}{
#'  Nb of '1 copy'}
#'  \item{morethanone}{
#'  Nb of 'More than one'}
#'  \item{total}{
#'  Total nb of '1 copy' and 'More than one'}
#'  \item{indexes}{
#'  '1 copy' Indexes}
#'  \item{vgene}{
#'  V-gene}
#'  \item{vallele}{
#'  V-allele}
#'  \item{dgene}{
#'  D-gene}
#'  \item{dallele}{
#'  D-allele}
#'\item{jgene}{
#'  J-gene}
#'  \item{jallele}{
#'  J-allele}
#'  \item{cdr1}{
#'  CDR1-IMGT}
#'  \item{cdr2}{
#'  CDR2-IMGT}
#'  \item{gcdr1}{
#'  CDR1-IMGT gapped sequence (AA)}
#'    \item{gcdr2}{
#' CDR2-IMGT gapped sequence (AA)}
#'  \item{pid}{
#'\% identity with the closest germline IMGT V gene and allele}
#' \item{length}{
#'  Sequence length}
#'\item{c104}{
#'  C104 (1st-CYS)}
#'\item{f118}{
#'  F118 or W118 (J-PHE or J-TRP)}
#'\item{anchors}{
#'  Anchors (C104, F118 or W118)}
#'\item{seqid}{
#'  Sequence ID}
#'\item{functionality}{
#'  Functionality}
#'\item{sequenceFileNumber}{
#'  Sequence file number}
#'\item{sequenceClonoFileNumber}{
#' Sequence clonotype file number}
#' @examples
#'\dontrun{
# Load the first set (MID1)
#'data(MID1)
# Load the second set (MID2)
#'data(MID2)
#'MID1<-clonRem(MID1)
#'MID2<-clonRem(MID2)
#'}
#' @export
clonRem <-function(set, min=4, max=45){
  set1rem<- subset(set,((nchar(as.character(set[,1]))<=max)==TRUE & (nchar(as.character(set[,1]))>=min)==TRUE))
  return(set1rem)
}

#' Differences in proportions graph
#'
#' This function draws the graph of differences in proportions of IMGT clonotypes (AA) (or sequences assigned to IMGT clonotypes (AA)) with significance and confidence interval (CI) bars.
#'
#' @param data the data isssued from the fuction \code{\link{sigrepDiv}} for clonotype diversity and from the function \code{\link{sigrepExp}} for clonotype expression
#' @param ... optional parameters
#' @import ggplot2
#' @import gridExtra
#' @importFrom reshape2 melt
#' @return Graph of differences in proportions of IMGT clonotypes (AA) (or sequences assigned to IMGT clonotypes (AA)) in the two compared sets from the IMGT/HighV-QUEST output with significance and confidence interval (CI) bars.
#' @name diffpropGph
#' @examples
#' \dontrun{
#' diffpropGph(div)$Vgenes
#' diffpropGph(div)$Jgenes
#' diffpropGph(div)$Dgenes
#' diffpropGph(exp)$Vgenes
#' diffpropGph(exp)$Jgenes
#' diffpropGph(exp)$Dgenes
#' }
#' @keywords IMGTHVQplots
#' @export
  diffpropGph<-function(data,...){
   colors=c("Null difference in proportions  "="#FFFFFF", "Non-significant (rawp)  "="#E40000", "Significant (rawp)  "= "cyan",
           "Significant (All_p)  "="#0026FF", "Significant (Min_2p)  "="#FF00DC","Significant (Only_BH)  "= "green3")
   pbrut <-with(data, ggplot(data,aes(x=factor(Gene_Name, levels=rev(factor(Gene_Name))),y =Difference_proportion))+
                 geom_errorbar(aes(col = Test_interpretation, ymin =Lower_bound_IC_diff_prop,
                                   ymax =Upper_bound_IC_diff_prop), cex=0.75, width=0.6)+ theme_grey()+coord_flip()+
                 geom_point(aes(shape = Test_interpretation), size = 1) +ylim( round(min(data$Lower_bound_IC_diff_prop)-0.01,2),  round(max(data$Upper_bound_IC_diff_prop)+0.01,2)) +
                 geom_hline(aes(yintercept = 0)) +
                 theme(
                   panel.grid.major = element_line(size = 0.5),
                   panel.border = element_rect(linetype = "solid", colour = "#808080", fill=NA),
                   legend.position="bottom",
                   plot.title=element_text( face="bold", size = unit(14, "pt")),
                   strip.text.x = element_text(size=unit(10, "pt"), colour="black"),
                   axis.title.x = element_text(size = unit(10, "pt"),face="bold", colour="black",vjust=-0.5),
                   axis.text.x=element_text(size = unit(10, "pt"), colour="black"),
                   strip.text.y = element_text(size=unit(10, "pt"), face="bold", colour="black"),
                   axis.title.y = element_text(size = unit(10, "pt"),face="bold", colour="black", vjust=1.5),
                   axis.text.y=element_text( size = unit(10, "pt"),hjust=0, colour="black"),
                   strip.background = element_rect( colour="#808080", fill="#DBDBDB", size=1, linetype="solid"),
                   legend.background = element_rect(colour = "black"),
                   legend.title = element_text(size=unit(8, "pt"), face="bold"),
                   legend.text = element_text(size = unit(8, "pt"), face = "bold",vjust=1.5),
                   legend.key.size = unit(0.4, "cm"))+
                 scale_color_manual(name="Test interpretation: ",
                                    values=colors,
                                    breaks=c("Null difference in proportions  ",
                                             "Non-significant (rawp)  ",
                                             "Significant (rawp)  ",
                                             "Significant (All_p)  ",
                                             "Significant (Min_2p)  ",
                                             "Significant (Only_BH)  "))+
                 scale_shape_manual(name="Test interpretation: ",values=c(19,19,19,19,19,19),
                                    breaks=c("Null difference in proportions  ","Non-significant (rawp)  ",  "Significant (rawp)  ",
                                             "Significant (All_p)  ",
                                             "Significant (Min_2p)  ",
                                             "Significant (Only_BH)  ")))

  Datav <- data[which(data$Gene_Type=="V gene"),]

  pv <- with(Datav,ggplot(Datav,aes(x=factor(Gene_Name, levels=rev(factor(Gene_Name))), y =Difference_proportion))+
               geom_errorbar(aes(col = Test_interpretation, ymin =Lower_bound_IC_diff_prop, ymax =Upper_bound_IC_diff_prop), cex=0.75, width=0.6)+ theme_grey()+coord_flip()+
               geom_point(aes(shape = Test_interpretation), size = 1) +
               ylab("Difference in proportions & 95% CI")+
               ylim( round(min(data$Lower_bound_IC_diff_prop)-0.01,2),  round(max(data$Upper_bound_IC_diff_prop)+0.01,2)) +
               geom_hline(aes(yintercept = 0)) + xlab("V genes")+
               theme(
                 panel.grid.major = element_line(size = 0.5),
                 panel.border = element_rect(linetype = "solid", colour = "#808080", fill=NA),
                 legend.position="bottom",
                 plot.title=element_text( face="bold", size = unit(14, "pt")),
                 strip.text.x = element_text(size=unit(10, "pt"), colour="black"),
                 axis.title.x = element_text(size = unit(10, "pt"),face="bold", colour="black",vjust=-0.5),
                 axis.text.x=element_text(size = unit(10, "pt"), colour="black"),
                 strip.text.y = element_text(size=unit(10, "pt"), face="bold", colour="black"),
                 axis.title.y = element_text(size = unit(10, "pt"),face="bold", colour="black", vjust=1.5),
                 axis.text.y=element_text( size = unit(10, "pt"),hjust=0, colour="black"),
                 strip.background = element_rect( colour="#808080", fill="#DBDBDB", size=1, linetype="solid"),
                 legend.background = element_rect(colour = "black"),
                 legend.title = element_text(size=unit(8, "pt"), face="bold"),
                 legend.text = element_text(size = unit(8, "pt"), face = "bold",vjust=1.5),
                 legend.key.size = unit(1.5, "cm"))+
               scale_color_manual(name="Test interpretation: ",
                                  values=colors,
                                  breaks=c("Null difference in proportions  ","Non-significant (rawp)  ", "Significant (rawp)  ", "Significant (All_p)  ",
                                           "Significant (Min_2p)  ","Significant (Only_BH)  "))+
               scale_shape_manual(name="Test interpretation: ",values=c(19,19,19,19,19,19),
                                  breaks=c("Null difference in proportions  ","Non-significant (rawp)  ",  "Significant (rawp)  ",
                                           "Significant (All_p)  ", "Significant (Min_2p)  ", "Significant (Only_BH)  ")))

  Dataj <- data[which(data$Gene_Type=="J gene"),]

  pj <- with(Dataj,ggplot(Dataj,aes(x=factor(Gene_Name, levels=rev(factor(Gene_Name))),
                                    y =Difference_proportion))+
               geom_errorbar(aes(col = Test_interpretation, ymin =Lower_bound_IC_diff_prop,
                                 ymax =Upper_bound_IC_diff_prop), cex=0.75, width=0.6)+ theme_grey()+coord_flip()+
               geom_point(aes(shape = Test_interpretation), size = 1) + ylab("Difference in proportions & 95% CI")+
               ylim( round(min(data$Lower_bound_IC_diff_prop)-0.01,2),  round(max(data$Upper_bound_IC_diff_prop)+0.01,2)) +
               geom_hline(aes(yintercept = 0)) + xlab("J genes")+
               theme(
                 panel.grid.major = element_line(size = 0.5),
                 panel.border = element_rect(linetype = "solid", colour = "#808080", fill=NA),
                 legend.position="bottom",
                 plot.title=element_text( face="bold", size = unit(14, "pt")),
                 strip.text.x = element_text(size=unit(10, "pt"), colour="black"),
                 axis.title.x = element_text(size = unit(10, "pt"),face="bold", colour="black",vjust=-0.5),
                 axis.text.x=element_text(size = unit(10, "pt"), colour="black"),
                 strip.text.y = element_text(size=unit(10, "pt"), face="bold", colour="black"),
                 axis.title.y = element_text(size = unit(10, "pt"),face="bold", colour="black", vjust=1.5),
                 axis.text.y=element_text( size = unit(10, "pt"),hjust=0, colour="black"),
                 strip.background = element_rect( colour="#808080", fill="#DBDBDB", size=1, linetype="solid"),
                 legend.background = element_rect(colour = "black"),
                 legend.title = element_text(size=unit(8, "pt"), face="bold"),
                 legend.text = element_text(size = unit(8, "pt"), face = "bold",vjust=1.5),
                 legend.key.size = unit(1.5, "cm"))+
               scale_color_manual(name="Test interpretation: ",
                                  values=colors,
                                  breaks=c("Null difference in proportions  ","Non-significant (rawp)  ",  "Significant (rawp)  ",
                                           "Significant (All_p)  ","Significant (Min_2p)  ","Significant (Only_BH)  "))+
               scale_shape_manual(name="Test interpretation: ",values=c(19,19,19,19,19,19),
                                  breaks=c("Null difference in proportions  ","Non-significant (rawp)  ",  "Significant (rawp)  ",
                                           "Significant (All_p)  ", "Significant (Min_2p)  ", "Significant (Only_BH)  ")))
  Datad <- data[which(data$Gene_Type=="D gene"),]
  pd <- with(Datad,ggplot(Datad,aes(x=factor(Gene_Name, levels=rev(factor(Gene_Name))),
                                    y =Difference_proportion))+
               geom_errorbar(aes(col = Test_interpretation, ymin =Lower_bound_IC_diff_prop,
                                 ymax =Upper_bound_IC_diff_prop), cex=0.75, width=0.6)+ theme_grey()+coord_flip()+
               geom_point(aes(shape = Test_interpretation), size = 1) + ylab("Difference in proportions & 95% CI")+
               ylim( round(min(data$Lower_bound_IC_diff_prop)-0.01,2),  round(max(data$Upper_bound_IC_diff_prop)+0.01,2)) +
               geom_hline(aes(yintercept = 0)) + xlab("D genes")+
               theme(
                 panel.grid.major = element_line(size = 0.5),
                 panel.border = element_rect(linetype = "solid", colour = "#808080", fill=NA),
                 legend.position="bottom",
                 plot.title=element_text( face="bold", size = unit(14, "pt")),
                 strip.text.x = element_text(size=unit(10, "pt"), colour="black"),
                 axis.title.x = element_text(size = unit(10, "pt"),face="bold", colour="black",vjust=-0.5),
                 axis.text.x=element_text(size = unit(10, "pt"), colour="black"),
                 strip.text.y = element_text(size=unit(10, "pt"), face="bold", colour="black"),
                 axis.title.y = element_text(size = unit(10, "pt"),face="bold", colour="black", vjust=1.5),
                 axis.text.y=element_text( size = unit(10, "pt"),hjust=0, colour="black"),
                 strip.background = element_rect( colour="#808080", fill="#DBDBDB", size=1, linetype="solid"),
                 legend.background = element_rect(colour = "black"),
                 legend.title = element_text(size=unit(8, "pt"), face="bold"),
                 legend.text = element_text(size = unit(8, "pt"), face = "bold",vjust=1.5),
                 legend.key.size = unit(1.5, "cm"))+
               scale_color_manual(name="Test interpretation: ",
                                  values=colors,
                                  breaks=c("Null difference in proportions  ","Non-significant (rawp)  ",  "Significant (rawp)  ",
                                           "Significant (All_p)  ","Significant (Min_2p)  ","Significant (Only_BH)  "))+
               scale_shape_manual(name="Test interpretation: ",values=c(19,19,19,19,19,19),
                                  breaks=c("Null difference in proportions  ","Non-significant (rawp)  ",  "Significant (rawp)  ",
                                           "Significant (All_p)  ", "Significant (Min_2p)  ", "Significant (Only_BH)  ")))
  list(VJgenes=pbrut,Vgenes=pv,Dgenes=pd,Jgenes=pj)}
